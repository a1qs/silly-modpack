PATCH NOTES 

Release v2.0.1

	-Fixed loom slot that was one pixel off
	-Added legacy_smithing.png so it is compatible with 1.19.4

Release v2.0.0

	-Reworked the visuals to be a bit further from vanilla and have it’s own more unique style
	-Changed to a more rounded look for inventories and menu buttons
	-Reworked some colors to be more pleasing to look at (mainly for the inventory slots)
	-Remade the shading style of the inventory slots, previews one could make some items appear to not be centered
	-Selection now has an intense yellow color to make it more distinct and because it looks cool
	-Remade the hotbar
	-Added different shapes for slots with different functions (like circles for hotbar and output)
	-Added shading to empty armor slots and other
	-Added a coffee pattern to most inventories (might not work properly with some mods due to tiling)
	-Added lines which separate hotbar, inventory and block interfaces
	-Added different sprites for progress bar of furnace, smoker and blast furnace
	-Changed trading arrows to be thumbs ups and downs cause why not
	-Cleaned up some unnecessary details on interfaces (like background for the map on cartography table or line details on loom and grindstone)
	-Added a little guy (Accessibility icon change)

Do not distribute or republish anywhere else without permission, the only page that offers this resourcepack is Modrinth and Planet Minecraft, and only by me. If you see any version of this resourcepack anywhere else, do not download, it was uploaded without my supervision and could be dangerous.

Modrinth: https://modrinth.com/resourcepack/dark-coffe-gui
Planet Minecraft: https://www.planetminecraft.com/texture-pack/dark-coffe-gui/
Ko-Fi (if you want 👉👈): https://ko-fi.com/restlesspip